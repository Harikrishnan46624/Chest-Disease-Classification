# chest > 2023-01-04 2:21pm
https://universe.roboflow.com/yokohama-city-university/chest-4mtjm

Provided by a Roboflow user
License: CC BY 4.0

